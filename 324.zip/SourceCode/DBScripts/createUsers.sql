DROP TABLE IF EXISTS user;
CREATE TABLE user (id varchar(10) not null, pwd varchar(10), cust_id int);
INSERT INTO user VALUES ('apatzer', 'apress', 6);
