\BuildFiles contains the Ant scripts used in chapters 10, 11, and 12.

\DBScripts contains the scripts used to create the databases used throughout the book.

\JavaCode contains the code used to create the JavaBeans and Custom Tags from the book.

\JSP contains the JSP files as well as the WEB-INF directory for each chapter of the book.